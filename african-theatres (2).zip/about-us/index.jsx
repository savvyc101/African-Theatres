import React from "react";
import { Navbar3 } from "./components/Navbar3";
import { Header44 } from "./components/Header44";
import { Layout195 } from "./components/Layout195";
import { Team6 } from "./components/Team6";
import { Gallery2 } from "./components/Gallery2";
import { Layout12 } from "./components/Layout12";
import { Footer7 } from "./components/Footer7";

export default function Page() {
  return (
    <div>
      <Navbar3 />
      <Header44 />
      <Layout195 />
      <Team6 />
      <Gallery2 />
      <Layout12 />
      <Footer7 />
    </div>
  );
}
