import React from "react";
import { Navbar3 } from "./components/Navbar3";
import { PortfolioHeader2 } from "./components/PortfolioHeader2";
import { Layout12 } from "./components/Layout12";
import { Layout246 } from "./components/Layout246";
import { Gallery3 } from "./components/Gallery3";
import { Cta27 } from "./components/Cta27";
import { Footer7 } from "./components/Footer7";

export default function Page() {
  return (
    <div>
      <Navbar3 />
      <PortfolioHeader2 />
      <Layout12 />
      <Layout246 />
      <Gallery3 />
      <Cta27 />
      <Footer7 />
    </div>
  );
}
