import React from "react";
import { Navbar3 } from "./components/Navbar3";
import { Header65 } from "./components/Header65";
import { Layout12 } from "./components/Layout12";
import { Layout238 } from "./components/Layout238";
import { Layout101 } from "./components/Layout101";
import { Testimonial4 } from "./components/Testimonial4";
import { Cta7 } from "./components/Cta7";
import { Contact2 } from "./components/Contact2";
import { Logo3 } from "./components/Logo3";
import { Footer7 } from "./components/Footer7";

export default function Page() {
  return (
    <div>
      <Navbar3 />
      <Header65 />
      <Layout12 />
      <Layout238 />
      <Layout101 />
      <Testimonial4 />
      <Cta7 />
      <Contact2 />
      <Logo3 />
      <Footer7 />
    </div>
  );
}
