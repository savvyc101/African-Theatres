import React from "react";
import { Navbar3 } from "./components/Navbar3";
import { Header47 } from "./components/Header47";
import { Layout6 } from "./components/Layout6";
import { Layout251 } from "./components/Layout251";
import { Testimonial6 } from "./components/Testimonial6";
import { Cta3 } from "./components/Cta3";
import { Layout6_1 } from "./components/Layout6_1";
import { Cta8 } from "./components/Cta8";
import { Footer7 } from "./components/Footer7";

export default function Page() {
  return (
    <div>
      <Navbar3 />
      <Header47 />
      <Layout6 />
      <Layout251 />
      <Testimonial6 />
      <Cta3 />
      <Layout6_1 />
      <Cta8 />
      <Footer7 />
    </div>
  );
}
