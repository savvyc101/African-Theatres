import React from "react";
import { Navbar3 } from "./components/Navbar3";
import { Header54 } from "./components/Header54";
import { Layout18 } from "./components/Layout18";
import { Layout238 } from "./components/Layout238";
import { Layout4 } from "./components/Layout4";
import { Cta1 } from "./components/Cta1";
import { Cta20 } from "./components/Cta20";
import { Faq3 } from "./components/Faq3";
import { Footer7 } from "./components/Footer7";

export default function Page() {
  return (
    <div>
      <Navbar3 />
      <Header54 />
      <Layout18 />
      <Layout238 />
      <Layout4 />
      <Cta1 />
      <Cta20 />
      <Faq3 />
      <Footer7 />
    </div>
  );
}
