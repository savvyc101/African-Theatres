import React from "react";
import { Navbar3 } from "./components/Navbar3";
import { Header62 } from "./components/Header62";
import { Layout18 } from "./components/Layout18";
import { Layout238 } from "./components/Layout238";
import { Layout24 } from "./components/Layout24";
import { Layout4 } from "./components/Layout4";
import { Layout1 } from "./components/Layout1";
import { Footer7 } from "./components/Footer7";

export default function Page() {
  return (
    <div>
      <Navbar3 />
      <Header62 />
      <Layout18 />
      <Layout238 />
      <Layout24 />
      <Layout4 />
      <Layout1 />
      <Footer7 />
    </div>
  );
}
